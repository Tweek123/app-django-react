self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "84d946101f22394b70b4e7e0e0bd83b4",
    "url": "/index.html"
  },
  {
    "revision": "311a23251b8273d135dc",
    "url": "/static/css/2.c37a399a.chunk.css"
  },
  {
    "revision": "0a78b1492fc8918156eb",
    "url": "/static/css/main.b20d268d.chunk.css"
  },
  {
    "revision": "311a23251b8273d135dc",
    "url": "/static/js/2.85ef94db.chunk.js"
  },
  {
    "revision": "0a78b1492fc8918156eb",
    "url": "/static/js/main.471df28c.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "3e97dbdbf4aa4665df1da7bc816d93ac",
    "url": "/static/media/Oswald-Medium.3e97dbdb.ttf"
  }
]);